import pygame
from pygame.locals import *
from setting import *
from support_functions import *


class BossFightWindow:

    """
    A class representing the graphical user interface for a boss fight in a game.
    It draws buttons for actions, boss with animation and allows both player and boss to do turns

    Attributes:
        boss_name : The name of the boss.

        boss_hp : The current health points of the boss.

        boss_damage : The damage inflicted by the boss.

        boss_xp : The experience points gained from defeating/sparing the boss.

        player (Player): The player object participating in the boss fight.

        player_hp : The current health points of the player.

        player_dmg : The player's damage output.

        buttons : A list of available action buttons.

        selected_button : Index of the currently selected action button.

        button_rects : Rectangles representing the position of action buttons on the screen.

        img : The boss's graphical representation.

        screen : The game screen surface.

        message_rect : Rectangle for displaying messages during the boss fight.

        messages : A list of messages to be displayed during the fight.

        mercy_count : Count of Mercy actions chosen by the player.

        turn : Indicates whose turn it is ('player' or 'boss').

        message_index : Index of the current message being displayed.

        message_timer : Timer to control the switching of messages.

        message_switch_delay : Delay before switching to the next message.

        message_display_time : Duration for displaying each message.

        boss_animation_frames: Frames for the boss's animation.

        current_frame_index : Index of the currently displayed animation frame.

        animation_delay : Delay between switching animation frames.

        last_animation_time : Timestamp of the last animation frame switch.

        player_turn_flag : Flag indicating whether it is the player's turn.

        


    Methods:
        update_animation(): Update the boss's animation frames based on a delay.

        update_button_rects(): Update the positions of action buttons on the screen.

        draw(): Draw the boss fight window with relevant information and graphics.

        handle_event(event): Handle user input events during the boss fight.

        handle_button_click(button_index): Handle button clicks based on the selected action.

        attack(): Perform an attack action on the boss.

        check(): Provide information about the boss's health, damage, and experience points.

        player_heal(amount): Allow the player to heal themselves.

        mercy(): Choose a Mercy action during the boss fight.

        switch_message(new_message): Switch the displayed message during the boss fight.
    """


    def __init__(self, player):
        self.boss_name = 'Shroom'
        self.boss_hp = Boss['health']
        self.boss_damage = Boss['damage']
        self.boss_xp = Boss['xp']
        self.player = player
        self.player_hp = player.health
        self.player_dmg = player.get_full_dmg()
        self.buttons = ["Attack", "Check", "Heal", "Mercy"]
        self.selected_button = 0  
        self.button_rects = []
        self.img = pygame.image.load('texture_packs/idle.png')
        self.screen = pygame.display.get_surface()
        self.message_rect = pygame.Rect(50, 250, self.screen.get_width() - 100, 100)
        self.messages = ["The Shroom appears"] # the very first message
        self.mercy_count = 0
        self.turn = 'player'
        self.message_index = 0
        self.message_timer = 0
        self.message_switch_delay = 2000
        self.message_display_time = 2000
        self.boss_animation_frames = load_all_pics('boss/')
        self.current_frame_index = 0
        self.animation_delay = 400 
        self.last_animation_time = pygame.time.get_ticks()

        self.player_turn_flag = True  

        self.update_button_rects()


    def update_animation(self):
        """
        The method updates the boss's animation frames based on a delay.
        This method checks if enough time has passed since the last animation frame update.
        If the delay has been reached, it increments the current frame index, ensuring it
        loops back to the start when reaching the end of the animation frames.

        Returns:
        None

        """
        current_time = pygame.time.get_ticks()
        if current_time - self.last_animation_time >= self.animation_delay:
            self.last_animation_time = current_time
            self.current_frame_index = (self.current_frame_index + 1) % len(self.boss_animation_frames)   


    def update_button_rects(self):

        """
        This method recalculates and updates the positions of the button rectangles based on the current
        screen dimensions and the number of buttons. It ensures that the buttons are horizontally centered
        and evenly spaced, maintaining a responsive layout. 
        Was added since authos was unsure about button count


        Returns:
        None

        """

        self.button_width = 150
        self.button_height = 60
        self.x_buttons = (self.screen.get_width() - len(self.buttons) * (self.button_width + 10)) // 2
        self.y_buttons = 470  

        self.button_rects = [
        pygame.Rect(
        self.x_buttons,
        self.y_buttons,
        self.button_width,
        self.button_height
        ) for i in range(len(self.buttons))
        ]




    def draw(self):

        """

            This method handles the rendering of various graphical elements, including boss and player health,
            action buttons, boss animations, and dialogue messages. It updates the display to reflect changes
            in the game state.


            Returns:
            None
        """

        self.screen.fill((0, 0, 0))


        # Render text displaying boss and player health
        font = pygame.font.Font(FONT, 30)
        boss_text = font.render(f"{self.boss_name} HP: {self.boss_hp}", True, (255, 255, 255))
        player_text = font.render(f"Player HP: {self.player.health}", True, (255, 255, 255))
        self.screen.blit(boss_text, (50, 50))
        self.screen.blit(player_text, (50, 100))



         # Draw action buttons and their text
        for i, rect in enumerate(self.button_rects):
            rect.x = self.x_buttons + i * (self.button_width+30) # 30 is responsible for button margin, i ensures proper spacing from start for each button
            rect.y = self.y_buttons 
            color = (255, 255, 255) if i == self.selected_button else (128, 128, 128)
            pygame.draw.rect(self.screen, color, rect)
            button_text = font.render(self.buttons[i], True, (0, 0, 0))
            text_rect = button_text.get_rect(center=(rect.centerx, rect.centery))
            self.screen.blit(button_text, text_rect)



        # Update boss animation and draw it on the screen
        self.update_animation()
        img_rect = self.img.get_rect(center=(self.screen.get_width() // 2, self.screen.get_height() // 2 - 150))
        current_frame = self.boss_animation_frames[self.current_frame_index]
        boss_animation_rect = current_frame.get_rect(center=img_rect.center)
        self.screen.blit(current_frame, boss_animation_rect)

    
      

        # Display dialogue message with a time delay between messages
        pygame.draw.rect(self.screen, (128, 128, 128), self.message_rect)
        current_time = pygame.time.get_ticks()
        if current_time - self.message_timer >= self.message_switch_delay:
            self.message_timer = current_time

            if self.message_index < len(self.messages):
                self.message = self.messages[self.message_index]
                self.message_index += 1

        message_text = font.render(self.message, True, (255, 255, 255))
        self.screen.blit(message_text, (self.message_rect.x + 10, self.message_rect.y + 10))
      


        pygame.display.flip()



    def handle_event(self, event):

        """
    Handles user input events during the player's turn in the boss fight.
    If the return key (K_RETURN) is pressed, it executes the action associated with the currently selected button by calling handle_button_click.

    Parameters:
        event (pygame.event.Event): The pygame event object representing the user's input.

    Returns:
    None


       """
        if self.turn == 'player' and self.player_turn_flag: 
            if event.type == KEYDOWN:
                if event.key == K_LEFT:
                    self.selected_button = (self.selected_button - 1) % len(self.buttons)
                elif event.key == K_RIGHT:
                    self.selected_button = (self.selected_button + 1) % len(self.buttons)
                elif event.key == K_SPACE:
                    self.handle_button_click(self.selected_button)




    def handle_button_click(self, button_index):
        """

    This method is called when a button is selected during the player's turn in the boss fight,
    and it executes the corresponding action based on the button's index.
 
    After handling the button click, it sets the turn to 'boss' and updates the player_turn_flag to False.

    Parameters:
        button_index (int): The index of the clicked button.

    Returns:
    None

        """
        if self.turn == 'player' and self.player_turn_flag: 
            if button_index == 0: 
                self.attack()
            elif button_index == 1:
                self.check()
            elif button_index == 2:  
                self.player_heal(10)
            elif button_index == 3:  
                self.mercy()
           
            self.turn = 'boss'
            self.player_turn_flag = False  




    def attack(self):
        self.boss_hp -= self.player_dmg
        self.switch_message(f"You dealt {self.player_dmg} damage to {self.boss_name}.")
     

    def check(self):
        self.switch_message(f"{self.boss_name} - HP: {self.boss_hp}, Damage: {self.boss_damage}, XP:{self.boss_xp}")
       

    def player_heal(self, amount):
        self.player.health = min(self.player.stats['health'], self.player.health + amount)
        self.switch_message(f"You healed for {amount} HP.")
       

    def mercy(self):
        self.mercy_count += 1
        self.switch_message("You chose Mercy.")
       
       
    def switch_message(self, new_message):
       
        self.message_timer = pygame.time.get_ticks()
        self.message_index = 0
        self.messages = [new_message]
    