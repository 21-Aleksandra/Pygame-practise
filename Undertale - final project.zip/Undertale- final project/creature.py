import pygame

class Creature(pygame.sprite.Sprite):

    """
    A base class for creatures in the game, both player and enemies. Later, those sprites will inherit from that class

    Attributes:
    - anim_speed : The animation speed of the creature.
    - anim_index : The current animation 'slide' index.
    - direction  : The movement direction vector.

    Methods:
    - __init__(groups): Initializes a Creature sprite.
    - collision(direction): Handles collisions in the specified direction.
    - move(speed): Moves the creature in the specified direction at the given speed.

    """





    def __init__(self,groups):
        super().__init__(groups)
        self.anim_speed=0.15
        self.anim_index=0
        self.direction = pygame.math.Vector2()


   
    def collision(self, direction):
        """
    This method checks for collisions between the creature's hitbox and obstacle sprites in the specified
    direction. If a collision is detected, it adjusts the hitbox position accordingly to prevent the creature
    from passing through obstacles.Basically, it moves it in opposite direction from obstacle

    Parameters:
    - direction : A string indicating the direction of collision ('horizontal' or 'vertical').

    Returns:
    None

      """
        if direction == 'horizontal':
            for sprite in self.obstacle_sprites:
                if sprite.hitbox.colliderect(self.hitbox):
                    if self.direction.x>0:
                        self.hitbox.right=sprite.hitbox.left #right move
                    
                    if self.direction.x<0:
                        self.hitbox.left=sprite.hitbox.right #left move


                    
        if direction == "vertical":
             for sprite in self.obstacle_sprites:
                if sprite.hitbox.colliderect(self.hitbox):
                    if self.direction.y>0:
                        self.hitbox.bottom=sprite.hitbox.top #up move
                    
                    if self.direction.y<0:
                        self.hitbox.top=sprite.hitbox.bottom #down move

            
    
    def move(self,speed):

        """
    This method updates the creature's position by adjusting the hitbox based on its normalized direction
    and the provided speed. It ensures that the creature moves consistently in both horizontal and vertical
    directions while handling collisions with obstacles.

    Parameters:
    - speed (float): The speed at which the creature should move.

    Returns:
    None


    """



        #normalazing vecor
        #if lenght of a vector isnt zero(has length) than normalize. Ensures all speeds the same
        if self.direction.magnitude()!=0:
            self.direction=self.direction.normalize()
        self.hitbox.x +=self.direction.x*speed
        self.collision('horizontal')
        self.hitbox.y +=self.direction.y*speed
        self.collision('vertical')
        self.rect.center = self.hitbox.center
        