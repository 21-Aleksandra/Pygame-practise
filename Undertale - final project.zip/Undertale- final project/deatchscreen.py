
import pygame
from setting import *

class DeathScreen:

    """
    Class representing the screens that appear when player dies or wins. Those screens allow to restart the game or exit, but show different information

    Attributes:
    - screen: The Pygame display surface.
    - font: custom font from settings with fixed size
    - width: Width of the screen from settings
    - height: Height of the screen from settings
    - restart_button_rect: Rectangular area for the restart button.
    - exit_button_rect: Rectangular area for the exit button.
    - selected_button: Currently selected button ("restart" or "exit").
    - death_image: Image displayed for the death screen.

    Methods:
    - __init__(self): Initializes the DeathScreen object with necessary attributes.
    - draw(self, type, current_time, prev_time): Draws the death/win screen on the Pygame display surface
    - handle_events(self): Handles Pygame events for button selection on the death/win screen.
    """




    def __init__(self):
        self.screen = pygame.display.get_surface()
        self.font = pygame.font.Font(FONT, 36)
        self.width = WIDTH
        self.height = HEIGTH
        self.restart_button_rect = pygame.Rect(self.width // 4, self.height // 2, self.width // 2, 50)
        self.exit_button_rect = pygame.Rect(self.width // 4, self.height // 2 + 60, self.width // 2, 50)
        self.selected_button = "restart"
        self.death_image = pygame.image.load('icons/broken_heart.png')


    def draw(self, type, current_time, prev_time):

        """
        The method fills the screen with a black color and then renders text, images, and buttons accordingly.
        If the screen type is "You died!", it displays the death text and image.
        If the screen type is "You win!", it additionally displays current and best time information.
        The color of the restart and exit buttons is adjusted based on the selected button. The selection is passed to antoher method to make actions
      

        Parameters:
        - type (str): Type of the screen ("You died!" or "You win!").
        - current_time (float): Current time played in seconds.
        - prev_time (float): Best time played in seconds.

        Returns:
        None
        

        """
    
        self.screen.fill((0, 0, 0))
        
        death_text = self.font.render(type, True, (255, 255, 255))
        text_rect = death_text.get_rect(center=(self.width // 2, self.height // 4 + 30))
        self.screen.blit(death_text, text_rect)

        if type=='You died!':
            image_rect = self.death_image.get_rect(center=(self.width // 2, self.height // 2 -70))
            self.screen.blit(self.death_image, image_rect)

        if type=='You win!':
            current_time_text = self.font.render(f"Current Time: {current_time} seconds", True, (255, 255, 255))
            current_time_rect = current_time_text.get_rect(center=(self.width // 2, self.height // 2 -100))
            self.screen.blit(current_time_text, current_time_rect)
            prev_time_text = self.font.render(f"Best Time: {prev_time} seconds", True, (255, 255, 255))
            prev_time_rect = prev_time_text.get_rect(center=(self.width // 2, self.height // 2 -70))
            self.screen.blit(prev_time_text, prev_time_rect)

        restart_color = (0, 0, 0)
        exit_color = (0, 0, 0)

        if self.selected_button == "restart":
            restart_color = (128, 128, 128)
        elif self.selected_button == "exit":
            exit_color = (128, 128, 128)

        pygame.draw.rect(self.screen, restart_color, self.restart_button_rect)
        restart_text = self.font.render("Restart", True, (255, 255, 255))
        restart_rect = restart_text.get_rect(center=self.restart_button_rect.center)
        self.screen.blit(restart_text, restart_rect)

        pygame.draw.rect(self.screen, exit_color, self.exit_button_rect)
        exit_text = self.font.render("Exit", True, (255, 255, 255))
        exit_rect = exit_text.get_rect(center=self.exit_button_rect.center)
        self.screen.blit(exit_text, exit_rect)

        pygame.display.flip()

    def handle_events(self):

        """

        The methodetects key presses (UP, DOWN, RETURN) to navigate and select restart/exit buttons.
        Returns the selected button when the RETURN key is pressed.

        Returns:
        - str: The selected button ("restart" or "exit").

        """



        keys = pygame.key.get_pressed()

        if keys[pygame.K_UP]:
            self.selected_button = "restart"
        elif keys[pygame.K_DOWN]:
            self.selected_button = "exit"
        elif keys[pygame.K_RETURN]:
            return self.selected_button



  