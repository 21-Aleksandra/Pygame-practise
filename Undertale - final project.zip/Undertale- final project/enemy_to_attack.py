import pygame
from setting import *
from creature import Creature
from support_functions import *


class Enemy(Creature):

    """
    A class representing an enemy in a game and all its possible actions and charastrictics such as name, xp, the ability to hit etc.

    Attributes:
        sprite_type : Type of the sprite, set to 'enemy'.
        status : Current status of the enemy ('idle', 'move', 'attack').
        img: The current image(visual state) of the enemy.
        name : The name of the enemy.
        rect: The rectangular area occupied by the enemy.
        hitbox: The hitbox area for collision detection.
        obstacle_sprites: Sprites representing obstacles for enemy in the game.
        can_be_attacked : Flag indicating if the enemy can be attacked.
        att_dur : Attack duration.
        hit_time: Timestamp of the last hit on the enemy.
        more_xp: Function to handle additional experience points.
        can_do_attack : Flag indicating if the enemy can perform an attack.
        health : Current health of the enemy.
        xp : Experience points awarded when the enemy is defeated.
        speed : Movement speed of the enemy.
        attack_damage: Damage dealed by the enemy's attack.
        resistance : Resistance of the enemy to being pushed back.
        attack_dist : Distance at which the enemy can acctack the player.
        notice_dist : Distance at which the enemy notices the player.
        vulnerable  : Flag indicating if the enemy can be damaged.
        no_hit_duration : Duration of invulnerability after being hit.
        attack_time : Timestamp of the last attack by the enemy.
        attack_cooldown : Cooldown period between attacks.
        damage_p: Function to handle damage of player.

    Methods:
        act(self, player): Perform actions based on the enemy's current status.

        import_pics(self, name): Load images for different animations.

        get_player_dist(self, player): Calculate distance and direction to the player.

        get_status(self, player): Determine the enemy's status based on player position.

        animation(self): Manage animation frames for the current status.

        pause(self): Handle cooldowns and invulnerability periods.

        get_damage(self, player): Receive damage from the player if vulnerable.

        death(self): Handle the enemy's death, triggering experience point reward.

        hit_push(self): React to being hit by adjusting movement direction and pushing back.

        update(self): Update the enemy's state in each game loop iteration.

        enemy_updater(self, player): Update the enemy's status and actions based on player position.
    """



    def __init__(self, name, pos, groups, obstacle_sprites, players_damage, more_xp):
        super().__init__(groups)
        self.sprite_type = 'enemy'
        self.import_pics(name)
        self.status = 'idle'
        self.image = self.animations[self.status][self.anim_index]
        self.name = name
        self.rect = self.image.get_rect(topleft=pos)
        self.hitbox = self.rect.inflate(0, -10)
        self.obstacle_sprites = obstacle_sprites
        self.can_be_attcked = True
        self.att_dur = 1400
        self.hit_time = None
        self.more_xp = more_xp
        self.can_do_attack = True
        monster_info = Monster[self.name]
        self.health = monster_info['health']
        self.xp = monster_info['xp']
        self.speed = monster_info['speed']
        self.attack_damage = monster_info['damage']
        self.resistance = monster_info['hit_dist']
        self.attack_dist = monster_info['att_dist']
        self.notice_dist = monster_info['notice_dist']
        self.vulnerable = True
        self.hit_time = None
        self.no_hit_duration = 500
        self.attack_time = 0
        self.attack_cooldown = 700
        self.damage_p = players_damage






    def act(self,player):

        """
        This method decides what actions to perform  based on the enemy's current status.
		It also updates the last attack timestamp if the status is 'attack'

        Parameters:
            player: The player object that the enemy interacts with.


        Returns:
        None

        """


        if self.status == 'attack':
            self.attack_time = pygame.time.get_ticks()
            self.damage_p(self.attack_damage)
        elif self.status == 'move':
            self.direction = self.get_player_dist(player)[1]
        else:
            self.direction = pygame.math.Vector2()



    def import_pics(self,name):

        """
        The method loads all pictures for each animation type and stores them in the animations dictionary.

        Parameters:
            name (str): The name of the enemy used to construct the path to the image files.

        Returns:
        None

        """
        self.animations = {'idle': [], 'move': [], 'attack': []}
        main_path = f'enemy/{name}/'
        for animation in self.animations.keys():
            self.animations[animation] = load_all_pics(main_path + animation)


    def get_player_dist(self,player):
        
        """
        Method calculates distance and direction to the player from the enemy.

        Parameters:
            player: The player object to whom distance and direction are calculated.

        Returns:
            tuple: A tuple containing the distance and normalized direction vector
                   from the enemy to the player. (It will than be multipled by speed for correct movement)
        """
        
        enemy_vec = pygame.math.Vector2(self.rect.center)
        player_vec = pygame.math.Vector2(player.rect.center)
        dist = (player_vec - enemy_vec).magnitude()

        if dist > 0:
            dir = (player_vec - enemy_vec).normalize()
        else:
            dir = pygame.math.Vector2()

        return (dist, dir)
    


    
    def get_status(self, player):
        """
        Determine the enemy's status based on player position(distance to enemy) and enemy notice and attack radius.

        Parameters:
            player: The player object whose distance is considered.

        Returns:
            None
        """
        distance = self.get_player_dist(player)[0]

        if distance <= self.attack_dist and self.can_do_attack:
            if self.status != 'attack':
                self.anim_index = 0
            self.status = 'attack'
        elif distance <= self.notice_dist:
            self.status = 'move'
        else:
            self.status = 'idle'




    def animation(self):
        
        """
    The method handles the progression of animation frames based on the current
    status of the enemy, updating the displayed image and its position accordingly.

    Returns:
    None
        
        """
        animation = self.animations[self.status]

        self.anim_index += self.anim_speed # games runs on 60 fps so 0.15 speed actually helps to process animation properly
        if self.anim_index >= len(animation):
            if self.status == 'attack':
                self.can_do_attack = False
            self.anim_index = 0

        self.image = animation[int(self.anim_index)]
        self.rect = self.image.get_rect(center=self.hitbox.center)
        


    def pause(self):
        
        """
        The method checks and updates the cooldown for the enemy's attack and
        the duration of invulnerability after being hit. It ensures that the
        enemy can perform attacks again and becomes vulnerable again.

        Returns:
        None
            
        """
        


        current_time = pygame.time.get_ticks()
        if not self.can_do_attack:
            if current_time - self.attack_time >= self.attack_cooldown:
                self.can_do_attack = True

        if not self.vulnerable:
            if current_time - self.hit_time >= self.no_hit_duration:
                self.vulnerable = True





    def get_gamage(self, player):
        
        """
        The method applies damage to the enemy if it is currently vulnerable as well as records the hit time,
        and sets the enemy to an invulnerable state for some period.

        Parameters:
            player: The player object inflicting damage.

        Returns:
            None
            
        """
        if self.vulnerable:
            self.direction = self.get_player_dist(player)[1]
            self.health -= player.get_full_dmg()
            self.hit_time = pygame.time.get_ticks()
            self.vulnerable = False

    def death(self):
        if self.health <= 0:
            self.kill()
            self.more_xp(self.xp)

    def hit_push(self):
        
        """
        
        The method applies a pushback effect to the enemy when it is hit, reducing its movement.

        Returns:
        None
            
        """
        if not self.vulnerable:
            self.direction *= -self.resistance

    def update(self):
        self.hit_push()
        self.move(self.speed) # inherits from creature class
        self.animation()
        self.pause()
        self.death()

    def enemy_updater(self, player):
        """
            Update the enemy based on its interaction with the player.
            
            Parameters:
                player: The player object the enemy interacts with.

            Returns:
            None
        """
        self.get_status(player)
        self.act(player)

