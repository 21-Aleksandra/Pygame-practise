import pygame
from setting import *



class UserInter:

    """
    Represents the user interface elements and displays for the game.

    Attributes:
    - surface : The main surface of the game display.
    - font : The font used for rendering text on the UI.
    - current_line_index : The index of the current dialogue line being displayed.
    - health_bar : Rectangular area representing the health bar on the UI.
    - xp_bar : Rectangular area representing the experience points bar on the UI.

    Methods:
    - __init__(self): Initializes a UserInter instance.
    - show_bar(self, curr, max, bg_rect, color): Displays a progress bar on the UI.
    - show(self, player): Displays player-related information such as hp and xp in the lesft corner.
    - show_enemy(self, enemy, player): Displays enemys health above them.
    - draw_dialogue(self, lines, who): Draws a dialogue box on the UI for specified characters.
    - close_dialogue(self): Closes the dialogue box.

    """





    def __init__(self):
        self.surface=pygame.display.get_surface()
        self.font=pygame.font.Font(FONT,STAND_FONT_SIZE)
        self.current_line_index = -1

        self.health_bar=pygame.Rect(10,10,HEALTH_BAR_W,BAR_H)
        self.xp_bar=pygame.Rect(10,40,XP_BAR_W,BAR_H)
       

    def show_bar(self,curr,max,bg_rect, color):

        """
        The method displays a progress bar on the UI.

        Parameters:
        - curr : Current value of the progress.
        - max : Maximum value of the progress.
        - bg_rect : Rectangular area representing the background of the progress bar.
        - color : RGB color tuple representing the color of the progress bar.

        Returns:
        None

      
        """

        pygame.draw.rect(self.surface,UI_BG_COL, bg_rect)
        hp_rt=curr/max
        curr_w=bg_rect.width*hp_rt
        curr_r=bg_rect.copy()
        curr_r.width=curr_w

        pygame.draw.rect(self.surface,color, curr_r)





    def show(self,player):

        """
        This method renders and displays player-related information on the UI, including the player's name,
        level, health and experience points bars, collected items, and item count.

        Parameters:
        - player (Player): An instance of the Player class representing the game player.

        Returns:
        None


    
        """



        name_text = self.font.render(f"Player: {player.name}", True, (255, 255, 255))
        level_text = self.font.render(f"Level: {player.lvl}", True, (255, 255, 255))
        self.surface.blit(name_text, (10, 70)) 
        self.surface.blit(level_text, (10, 90))
        self.show_bar(player.health, player.stats['health'],self.health_bar,H_COLOR )
        self.show_bar(player.XP, player.stats['XP'],self.xp_bar,XP_COLOR )
        collect_image = pygame.image.load('texture_packs/collect.png')
    

        collect_rect = collect_image.get_rect(topleft=(10, 128))
        self.surface.blit(collect_image, collect_rect)

        item_count_text = self.font.render(f"{player.item_count} X", True, (255, 255, 255))
        self.surface.blit(item_count_text, (collect_rect.right, 130))

    def show_enemy(self,enemy, player):
        """
          This method renders and displays the enemy's health bar above enemy. To insure that it does not allow YSortCamera to move them

        Parameters:
        - enemy (Enemy): An instance of the Enemy class representing an in-game enemy.
        - player (Player): An instance of the Player class representing the game player.

        Returns:
        None


        """
        self.vector=pygame.math.Vector2(100,200)
        self.display_surface=pygame.display.get_surface()
        self.half_w=self.display_surface.get_size()[0]//2
        self.half_h=self.display_surface.get_size()[1]//2
        self.vector.x= player.rect.centerx -self.half_w
        self.vector.y=player.rect.centery -self.half_h
        monster_bar_position = enemy.hitbox.centerx - self.vector.x, enemy.hitbox.y - self.vector.y-20

        self.monster_bar = pygame.Rect(monster_bar_position, (20, 10))
        self.show_bar(enemy.health, Monster['ghost']['health'],self.monster_bar,H_COLOR )

    def draw_dialogue(self, lines, who):
            
            """
        This method renders and displays a dialogue box on the screen, including the character image if needed

        Parameters:
        - lines (list): A list of dialogue lines to be displayed.
        - who (str): Specifies the character associated with the dialogue (e.g., 'toriel').

        Returns:
        None

    
        """
        
            self.dialogue_bar=pygame.Rect(20,500,1240,200)
            pygame.draw.rect(self.surface,"black", self.dialogue_bar)
            border_width = 5  
            pygame.draw.rect(self.surface, 'white', self.dialogue_bar)  
            pygame.draw.rect(self.surface, 'black', self.dialogue_bar.inflate(-border_width*2, -border_width*2))
            font = pygame.font.Font(FONT, 36)
            text = font.render(lines[self.current_line_index], True, 'white')
            text_rect = text.get_rect(center=self.dialogue_bar.center)
            self.surface.blit(text, text_rect)

            if who=='toriel':
                 tori_image = pygame.image.load('texture_packs/tori_dial.png')  
                 tori_rect = tori_image.get_rect(topleft=(110, 550))  
                 self.surface.blit(tori_image, tori_rect)

    def close_dialogue(self):
        self.dialogue_bar = None



        
      