from typing import Iterable, Union
import pygame
import os
import sys
from pygame.sprite import AbstractGroup
from setting import *
from support_functions import *
from tiled_map import Tile
from player import Player
import time
from weapon import Weapon
from interface_elements import UserInter
from enemy_to_attack import Enemy
from deatchscreen import DeathScreen
from bosswindow import BossFightWindow



class Level:


    """

    The Level class represents a game level of the Undertale game. It manages various game elements such as the player,
    enemies, obstacles, items, and interfaces. It is responsible for creating and updating the game world,
    handling player actions, managing dialogue sequences, and controlling boss fights.



    Attributes:
        curr_att (Weapon): The current weapon the player is using for attacks.

        to_attack : A group of sprites that can be attacked by the player.

        doing_attack: A group containing of sprites that can attacks.

        display_surface: The main game window surface.

        visible_sprites (YSortCameraGroup): A custom sprite group for managing and drawing visible game elements.

        obstacle_sprites : A group containing sprites representing obstacles that are invisible.

        enemy_group: A list containing instances of Enemy class representing enemies in the level.

        was_pressed: Flag to track whether a key was pressed during dialogues.

        interface: An instance of the UserInter class handling user interface elements.

        dialogue_lines: A list of basic dialogue lines displayed during interaction with character.

        last_key_press_time : The timestamp of the last key press event.

        press_count : Counter to track the number of key presses.

        dialogue_was_shown : Flag indicating whether dialogue has been shown to the player.

        death_screen (DeathScreen): An instance of the DeathScreen class for displaying the game over screen.

        win_screen (DeathScreen): An instance of the DeathScreen class for displaying the victory screen.

        start_time : The timestamp when the level started.

        player_died : Flag indicating whether the player has ended the game, not dead. Used for reading loop interuption
        
        time_played : The total time the player has spent in the level.

        best_time : The best completion time achieved in the level. Initially set to infinity for further managing

        best_time_file : The filename for storing the best completion time.

        player_has_won : Flag indicating whether the player has successfully completed the level.

        message_switch_delay : The delay time between switching messages during a boss fight.

        message_display_time : The duration for displaying messages during a boss fight.

        boss_fighting : Flag indicating whether the player is engaged in a boss fight.




    Methods:

        make_att(self): Creates a new weapon instance for the player's attack.

        destroy_sword(self): Destroys the current weapon.

        create_map(self): Populates the game world with tiles, obstacles, enemies.

        how_player_attacks(self): Handles logic for player attacks and collision with attack targets.

        check_boss(self): Checks if the player is in collision with the boss sprite.

        kill_boss(self): Destroys the boss sprite if the boss fight is completed.

        check_dialogue(self): Checks if the player is in collision with a character for initiating dialogue.

        players_damage(self, damage): Handles player damage and vulnerability.

        more_xp(self, how_much): Awards the player with additional experience points.

        lvl_up(self): Levels up the player.

        dialogue_control(self): Manages the flow of dialogue interactions.

        open_door(self): Checks if the player is in cossision with a door

        door_dialogue(self): Displays dialogue related to the door.

        collect_item(self): Checks if the player is in collision with collectible items and collects them.

        show_win_screen(self): Displays the victory screen when the player successfully completes the level.

        save_best_time_to_file(self): Saves the best completion time to a file.

        load_best_time_from_file(self): Loads the best completion time from a file.

        show_death_screen(self): Displays the game over screen when the player dies.

        boss_fight(self): Manages the flow of a boss fight, handling turns, attacks, and messages.

        boss_turn(self): Handles the logic for the boss's turn during a boss fight.

        restart_game(self): Resets the level and resets atributes

        attack_sound : the sound of enemy attack/damage for player

        collect_sound : sound of collecting item


    """






    def __init__(self,game):
           self.game=game
           self.curr_att=None
           self.to_attack = pygame.sprite.Group()
           self.doing_attack= pygame.sprite.Group()
           self.display_surface=pygame.display.get_surface()
           self.visible_sprites=YSortCameraGroup()
           self.obstacle_sprites=pygame.sprite.Group() # the collision logic is handaled in creature class
           self.enemy_group=[]
           self.create_map()
           self.was_pressed = False
           self.interface=UserInter()
           self.dialogue_lines = [f'Hello, fallen child {self.player.name}','You need to collect 3 golden pieces to win','Please take one next to me'] 
           self.last_key_press_time =0
           self.press_cound=0
           self.dialogue_was_shown=False
           self.death_screen=DeathScreen()
           self.win_screen=DeathScreen()
           self.start_time = 0
           self.player_died = False
           self.time_played =0
           self.best_time = float('inf')
           self.best_time_file = 'best_time.txt'
           self.player_has_won=False
           self.message_switch_delay = 2000
           self.message_display_time = 4000
           self.boss_fighting=True
           self.attack_sound=pygame.mixer.Sound('sound/Enemy_hit.mp3')
           self.attack_sound.set_volume(0.4)
           self.collect_sound=pygame.mixer.Sound('sound/collect.mp3')
           self.collect_sound.set_volume(0.4)
     

           

           
          
           

           
           
           



    def make_att(self):

          """

        Creates a new weapon instance for the player's attack which is visible and can attack.
        This method is called when the player initiates an attack. 

        Returns:
        None

          """

          self.curr_att=Weapon(self.player, [self.visible_sprites, self.doing_attack])
        


    def destory_sword(self):
      if self.curr_att:
            self.curr_att.kill()
      self.curr_att=None





    def create_map(self):
          

          """

        The method reads layout information from CSV files and creates game elements based on the defined styles. It makes position accoring to map tile size. 
        It also loads grafics for some specific objects or object groups.
        The method utilizes the 'Tile' class to create instances of various sprites and adds them to appropriate sprite groups for proper managment.

        Returns:
        None

           """
       
          layouts={
                'outline':get_layout_from_csv('levels/cvs_grafics/Undertale map_Floor_Blocks.csv'),
                'plates': get_layout_from_csv('levels/cvs_grafics/Undertale map_Plate.csv'),
                'objects_2':get_layout_from_csv('levels/cvs_grafics/Undertale map_objects_3.csv'),
                'creatures':get_layout_from_csv('levels/cvs_grafics/Undertale map_Enemies.csv'),
                'toriel':get_layout_from_csv('levels/cvs_grafics/Undertale map_toriel.csv'),
                'collect':get_layout_from_csv('levels/cvs_grafics/Undertale map_Collect.csv'),
                'door':get_layout_from_csv('levels/cvs_grafics/Undertale map_Door.csv'),
                'boss':get_layout_from_csv('levels/cvs_grafics/Undertale map_Boss.csv')
          }

         

          graf = {
                'objects_2':load_all_pics('levels/Objects')
          }
          
       

          for style, layout in layouts.items():
                for row_index, row, in enumerate(layout):
                      for col_index, col in enumerate(row):
                            if col != '-1':
                                  x=col_index*TILESIZE
                                  y=row_index*TILESIZE
                                  if style == 'outline':
                                        Tile((x,y), [self.obstacle_sprites], 'invisible')
                                  if style == 'plates':
                                         image = pygame.image.load('levels/Plates/plate.png')
                                         Tile((x, y), [self.visible_sprites, self.obstacle_sprites, self.to_attack], 'plate', image)
                                  if style == 'objects_2':
                                        if col=='2' :
                                               place=graf['objects_2'][int(col)]
                                               Tile((x,y), [self.visible_sprites], 'objecys2', place)

                                        else:
                                              place=graf['objects_2'][int(col)]
                                              Tile((x,y), [self.visible_sprites,self.obstacle_sprites], 'objecys2', place)

                                  if style== 'creatures':
                                        if col=='263': # this is tile id from Tiled
                                              self.player = Player((x,y),[self.visible_sprites], self.obstacle_sprites, self.make_att, self.destory_sword,self.lvl_up)
                                             
                                              
                                        else:
                                              self.enemy=Enemy('ghost',(x,y),[self.visible_sprites,self.to_attack],self.obstacle_sprites,self.players_damage, self.more_xp)
                                              self.enemy_group.append(self.enemy)

                                  if style=='toriel':
                                        img=pygame.image.load('levels/tori/tori.png')
                                        Tile((x,y), [self.visible_sprites], 'toriel', img)

                                  if style=='collect':
                                         collect_img=pygame.image.load('texture_packs/collect.png')
                                         Tile((x,y), [self.visible_sprites], 'collect', collect_img)

                                  if style=='door':
                                       Tile((x,y), [self.obstacle_sprites], 'door')

                                  if style=='boss':
                                       boss_img=pygame.image.load('texture_packs/idle.png')
                                       Tile((x,y), [self.visible_sprites, self.obstacle_sprites], 'boss',boss_img)

                                       
                                        


                              



    def how_player_attacks(self):
          
          """

        Handles the logic for player attacks and their interactions with other sprites.
        This method checks if the player is currently performing an attack (indicated by the 'doing_attack' sprite group).
        If an attack is in progress, it detects collisions with other sprites in the 'to_attack' sprite group.
        Depending on the type of sprite collided with appropriate actions are taken.

        Returns:
        None

          """
          if self.doing_attack:
                for attack_sprite in self.doing_attack:
                  collision_sprites = pygame.sprite.spritecollide(attack_sprite,self.to_attack,False)
                  if collision_sprites:
                        for target_sprite in collision_sprites:
                               if target_sprite.sprite_type == 'plate':
                                    target_sprite.kill()
                               else:
                                     target_sprite.get_gamage(self.player)


      
    def check_boss(self):

        """
        The method examines the visible sprites in the game, looking for both the player and the boss.
        If both the player and the boss are present, it checks whether their respective rectangles collide.
        If a collision is detected, the method returns True.

        Returns:
            bool: True if the player is in proximity to the boss, False otherwise.

         """
        
        if self.visible_sprites:
            boss = None
            player = None
            for sprites in self.visible_sprites:
                if sprites.sprite_type == 'boss':
                    boss = sprites
                elif sprites.sprite_type == 'player':
                    player = sprites

            if boss and player:

                if boss.rect.colliderect(player.rect):
             
                     return True
                


    def kill_boss(self):
        if self.visible_sprites:
            boss = None
            for sprites in self.visible_sprites:
                if sprites.sprite_type == 'boss':
                    boss = sprites

                    if self.boss_fighting==False:
                         boss.kill()
    
                 
    
            

    def check_dialogue(self):

        """
        This method examines the visible sprites in the game, looking for both the player and the character (named Toriel)
        with whom the player can interact for dialogue. If both the player and the character are present, it checks whether
        their respective rectangles collide. If a collision is detected, the method returns True, allowing to indicate of dialogue.

        Returns:
            bool: True if the player is in proximity to a character for dialogue, False otherwise.

        """
        if self.visible_sprites:
            toriel = None
            player = None
            for sprites in self.visible_sprites:
                if sprites.sprite_type == 'toriel':
                    toriel = sprites
                elif sprites.sprite_type == 'player':
                    player = sprites

            if toriel and player:

                if toriel.rect.colliderect(player.rect):
                     return True
             


    def players_damage(self,damage):
          
          """

        This method is responsible for handling the damage dealed to the player. If the player is currently in a vulnerable state,
        it deducts the specified damage from the player's health, updates the vulnerability status, and records
        the time of the last hit.

        Parameters:
            damage (int): The amount of damage to be applied to the player's health.

        Returns:
        None

          """



          if self.player.vulnerable:
                self.player.health-=damage
                if self.player.health>0:
                     self.attack_sound.play()
                
                self.player.vulnerable=False
                self.player.hit_time=pygame.time.get_ticks()

    
    def more_xp(self,how_much):
          
          """
        Increases the player's experience points (XP) by a specified amount. It is used to reward player for winning fights with enemies

        Parameters:
            how_much (int): The amount of XP to be added to the player.

        Returns:
        None

        """
          

          self.player.XP+=how_much



    def lvl_up(self):
          self.player.XP=0
          self.player.lvl+=1
          self.player.stats['health']+=20
          self.player.health+=20
          self.player.stats['attack']+=10




    def dialogue_control(self):
          """

        The method manages the starting and progression of dialogue sequences between player and Toriel. It checks for player key input to advance
        through dialogue lines. If the dialogue has been shown previously, it updates the dialogue lines accordingly.
        If the player presses the space key and meets the conditions, it advances to the next dialogue line and updates
        the display. When the last dialogue line is reached, the method closes the dialogue window.

        Returns:
        None

           """
          
          keys = pygame.key.get_pressed()

          if self.dialogue_was_shown:
               self.dialogue_lines = [f'Hello again {self.player.name}','You can find pieces in the other rooms','Good luck'] 

          if keys[pygame.K_SPACE] and (time.time() - self.last_key_press_time > 0.2) and self.check_dialogue():
            self.interface.current_line_index = (self.interface.current_line_index + 1) 
            self.last_key_press_time = time.time()
            self.was_pressed = True
       

          if self.interface.current_line_index < len(self.dialogue_lines) and self.check_dialogue() and self.was_pressed:
            self.interface.draw_dialogue(self.dialogue_lines, 'toriel')
            

          elif self.check_dialogue() and self.interface.current_line_index == 3:
            self.interface.current_line_index =-1
            self.was_pressed = False
            self.interface.close_dialogue()
            self.dialogue_was_shown=True





    def open_door(self):
         
         """

        The method checks if the playerhas a collision  with a door sprite

        Returns:
            bool: True if the player is near a door, False otherwise.

        """
         
         door=[]
         player=None
         for sprites in self.visible_sprites:
              if sprites.sprite_type == 'player':
                     player = sprites
         for doors in self.obstacle_sprites:
              if doors.sprite_type=='door':
                     door.append(doors)
         for door_blocks in door:
              if door_blocks.rect.colliderect(player.rect):
                   return True
              

              
    def door_dialogue(self):

        """
        Method anages dialogue related to the door, providing information on collecting pieces(have player collected all or not).
        When the last dialogue line is reached, the method closes the dialogue window.

        Returns:
        None

        """
        keys = pygame.key.get_pressed()

        self.dialogue_lines_door = ['You need to find all 3 pieces'] 
        
        if self.player.item_count < 3:
            if (keys[pygame.K_SPACE] and (time.time() - self.last_key_press_time > 0.2) and self.open_door):
                self.interface.current_line_index += 1
                self.last_key_press_time = time.time()
                self.was_pressed = True

            if ( self.interface.current_line_index < len(self.dialogue_lines_door)and self.open_door() and self.was_pressed ):
                self.interface.draw_dialogue(self.dialogue_lines_door, 'door')

            elif self.open_door() and self.interface.current_line_index == 1:
                self.interface.current_line_index = -1
                self.was_pressed = False
                self.interface.close_dialogue()

       
           
         
             
                     


    def collect_item(self):
          
          """
        The method handles player interaction with collectible items, updating item count of player when collected.

        Returns:
        None

    
          """

          if self.visible_sprites:
            items = []
            player = None
            for sprites in self.visible_sprites:
                if sprites.sprite_type == 'collect':
                    items.append(sprites)
                elif sprites.sprite_type == 'player':
                    player = sprites

            for item in items:
                if item.rect.colliderect(player.rect):
                      keys = pygame.key.get_pressed()
                      if keys[pygame.K_q]:
                           self.player.item_count+=1
                           self.collect_sound.play()
                           item.kill()


    def show_win_screen(self):
            
            """
        The method displays the win screen, providing a visual representation of the player's victory.
        Calculates and updates the best time played, and allows the player to choose between
        restarting the game or exiting.

        Returns:
        None

           """
            
            

            
            action = None 
            if not self.player_died:
                 end_time = time.time()
                 self.time_played = end_time - self.start_time

       
                 self.load_best_time_from_file()

                 if self.time_played < self.best_time:
                      self.best_time = self.time_played
             

                 self.save_best_time_to_file()

     
            self.player_died = True
  

            self.win_screen.draw('You win!', round(self.time_played,2), round(self.best_time,2) )
            
            action =  self.win_screen.handle_events()

            if action == "restart":
                self.restart_game()
              
            elif action == "exit":
                pygame.quit()
                exit()


    def save_best_time_to_file(self):
        with open(self.best_time_file, 'w') as file:
            file.write(str(self.best_time))


    def load_best_time_from_file(self):
         if os.path.exists(self.best_time_file):
            with open(self.best_time_file, 'r') as file:
                try:
                    self.best_time = float(file.read())
                except ValueError:
                    print("Error reading best time from file.")
    

    def show_death_screen(self):

        """
        The method displays the death screen, providing a visual representation of the player's defeat.
        Allows the player to choose between restarting the game or exiting.

        Returns:
        None


        """


        action = None 

  

        self.death_screen.draw('You died!',0, 0 )  


            
        action = self.death_screen.handle_events()

        if action == "restart":
            self.restart_game()
     
              
        elif action == "exit":
            pygame.quit()
            exit()


    def boss_fight(self):

        """
        The method initiates and manages the boss fight sequence.
        Displays the boss fight window, handles player and boss turns, and determines the outcome of the battle based on health
        as well as rewards the player with experience points after defeating the boss. It also allows to gently exit window without errors

        Returns:
        None

  

        """
        


        if self.check_boss():
            boss_fight_music=pygame.mixer.Sound('sound/Boss.mp3')
            boss_fight_music.play(loops=-1)
            
            self.boss_window = BossFightWindow(self.player)
            switch_time = pygame.time.get_ticks()
            message_time = 0

            while self.boss_fighting:
                for event in pygame.event.get():
                    if event.type == pygame.QUIT:
                        pygame.quit()
                        sys.exit()

                    self.boss_window.handle_event(event)

                elapsed_time = pygame.time.get_ticks() - switch_time

                if elapsed_time >= self.message_switch_delay + message_time:
                    self.boss_window.player_turn_flag = True
                    self.boss_window.turn = 'player'
                    self.boss_window.message = "It's your turn."
                    switch_time = pygame.time.get_ticks()  
                    message_time = 0 

                self.boss_window.draw()
               
              

       
                if self.boss_window.boss_hp <= 0:
                     self.boss_fighting = False
                     self.player.XP += 150
                     boss_fight_music.stop()

    
                     self.boss_window.message = "Congratulations! You have defeated the boss!"
                     self.boss_window.turn = 'player'
                     self.boss_window.draw()
                     pygame.time.delay(3000)
               
                     self.game.game_sound.play(loops=-1)
                     break
                
                elif self.boss_window.mercy_count ==3:
                     self.boss_fighting = False
                     boss_fight_music.stop()
                     self.game.game_sound.play(loops=-1)
                     self.player.XP += 150

    
                     self.boss_window.message = "Congratulations! You have spared the boss!"
                     self.boss_window.turn = 'player'
                     self.boss_window.draw()
                     pygame.time.delay(3000)  
                     break

                elif self.player.health <= 0:
                    self.boss_fighting=False
                    boss_fight_music.stop()
                    self.game.game_sound.play(loops=-1)
                    break
           
                if self.boss_window.turn == 'boss':
                    self.boss_turn()
                    message_time = self.message_display_time 

    def boss_turn(self):

        """
        The method simulates the boss's turn in the boss fight.
        When there is a boss turn, it reduces the player's health and updates the displayed message with the boss's attack details.
        It also switches the turn back to the player

        Returns:
        None
            
        """

        self.player.health -= self.boss_window.boss_damage
        message = f"{self.boss_window.boss_name} attacked you for {self.boss_window.boss_damage} damage."
        self.boss_window.message = message
        self.boss_window.current_message_time = self.boss_window.message_display_time
        
        self.boss_window.turn = 'player' 

             



            
         

    def restart_game(self):
        self.visible_sprites.empty()
        self.obstacle_sprites.empty()
        self.to_attack.empty()
        self.doing_attack.empty()
  
        self.enemy_group.clear()
    

        self.start_time = 0
        self.player_died = False
        self.player_has_won=False
        self.boss_fighting=True
 
      
        self.create_map()
          
      
                           

                     
         



    def run(self):
         
          self.visible_sprites.custom_draw(self.player)
          self.visible_sprites.update()
          self.how_player_attacks()
          self.visible_sprites.enemy_updater(self.player)
          for enemy in self.enemy_group:
                if enemy.health>0:
                      self.interface.show_enemy(enemy, self.player)
          self.interface.show(self.player)
          self.dialogue_control()
          self.collect_item()
          self.door_dialogue()
          if self.player.health <= 0:
               self.show_death_screen()
          if self.start_time == 0:
            self.start_time = time.time()
          if self.player.item_count==3 and self.open_door():
                   self.player.direction= pygame.math.Vector2()
                   self.player_has_won = True

          if self.player_has_won:
               self.show_win_screen()
          ok=self.check_boss()
          if ok:
               self.game.game_sound.stop()
          self.boss_fight()
          self.kill_boss()
               
        

         
         
          


class YSortCameraGroup(pygame.sprite.Group):
      
      """
    This class represents custom sprite group with a camera system for sorting and drawing sprites based on y-coordinate.

    Attributes:
        display_surface : The surface on which sprites will be drawn.
        half_w : Half the width of the display surface for camera positioning.
        half_h : Half the height of the display surface for camera positioning.
        vector : A vector representing the camera position.
        lowest : Image representing the floor.
        lowest_rect : Rectangle representing the position of the floor image.

    Methods:

        __init__(self): Initializes YSortCameraGroup attributes.

        custom_draw(self, player): Draws sprites with a camera system.

        enemy_updater(self, player): Updates enemy positions 

       """
      



      def __init__(self):
            
            """
      The method initializes YSortCameraGroup attributes. The use of super() ensures
      that the YSortCameraGroup class retains the functionality of its superclass (pygame.sprite.Group).
   
          """

            super().__init__()

            self.display_surface=pygame.display.get_surface()
            self.half_w=self.display_surface.get_size()[0]//2
            self.half_h=self.display_surface.get_size()[1]//2
            self.vector=pygame.math.Vector2(100,200)
            self.lowest=pygame.image.load('levels/lowest.png').convert()
            self.lowest_rect=self.lowest.get_rect(topleft=(0,0))






      def custom_draw(self, player):
            
            """

        This method updates the camera position based on the player's location,
        calculates the offset for drawing the floor image, and blits the floor image
        onto the display surface. It then sorts and draws sprites based on their vertical
        position (centery). The floor acts as the background.

        Parameters:
        - player (Sprite): The player sprite whose position acts as the camera focus.

        Returns:
        None

        
           """
            
            self.vector.x= player.rect.centerx -self.half_w
            self.vector.y=player.rect.centery -self.half_h

            floor_offset=self.lowest_rect.topleft- self.vector 
            self.display_surface.blit(self.lowest,floor_offset)

            # creates a depth order, ensuring sprites closer to the bottom of the screen are drawn on top.

            for sprite in sorted(self.sprites(), key= lambda sprite: sprite.rect.centery): # self.sprites comes from pygame.sprite.Group
                  offset=sprite.rect.topleft - self.vector
                  self.display_surface.blit(sprite.image, offset)




      def enemy_updater(self,player):
            
            """
        Updates each enemy sprite based on the player's position.

        Parameters:
        - player (Sprite): The player sprite whose position affects the enemy update.

        Returns:
        None
        """
            enemy_sprites = [sprite for sprite in self.sprites() if hasattr(sprite,'sprite_type') and sprite.sprite_type == 'enemy']
            for enemy in enemy_sprites:
                  enemy.enemy_updater(player) # this is not a recursive function but the enemy class method with the same naming 
                  
  