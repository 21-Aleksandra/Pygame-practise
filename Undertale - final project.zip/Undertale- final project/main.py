import pygame
import sys
from level import Level
from setting import *
from support_functions import *


 
class Game:

    """

    The Game class purpose is to be the controlling instance of the Undertale game core elements.
    It helps set up and manage the main game window and its screens, implement the game loop,
    and ensure interactions with the game level.

    Attributes:
        screen : The main game window surface.

        clock  : Pygame clock object for controlling frame rate.
        
        level  : An instance of the Level class, that represents the game level.

        slideshow_sound: sound for sildeshow before game 

        self.main_menu_sound: sound for main menu 

        game_sound: sound of main game level



    Methods:
        __init__(self): Initializes the main game atributes and class itself

        run(self): The main game loop that handles events and runs the level itself

        main_menu(self): Displays the main menu of the game

        slideshow(self): Displays a pre-game slideshow

    """


    def __init__(self):
        pygame.init()
        self.screen = pygame.display.set_mode((WIDTH,HEIGTH))
        pygame.display.set_caption("Undertale")
        icon=pygame.image.load("icons/Undertale.png")
        pygame.display.set_icon(icon)
        self.clock = pygame.time.Clock()
        self.level=Level(self)
        self.slideshow_sound = pygame.mixer.Sound("sound/Backstory.mp3")
        self.main_menu_sound = pygame.mixer.Sound("sound/Menu.mp3")
        self.game_sound = pygame.mixer.Sound("sound/Main.mp3")
       

   

    
    def run(self):
        self.game_sound.play(loops=-1) 
        while True:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
 
            self.screen.fill('black')
            self.level.run()

            pygame.display.update()
            self.clock.tick(FPS) #frame rate control

    def main_menu(self):

        """

        Displays the main menu screen with background picture (GUI) with option to start the game.
        The method listens for user input events, and if the user hits the Enter key,
        it closes the menu by updating the 'running' flag accordingly.

        If the user closes the game window by clicking on the cross in the upper right corner,
        the method exits the application without causing any errors.

        Returns:
        None

        """

        self.main_menu_sound.play(loops=-1) 

        background_image = pygame.image.load("background/background.v1.png")
        background_rect = background_image.get_rect()
        background_rect.center = (WIDTH // 2, HEIGTH // 2)
  

        running = True

        while running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    
                    pygame.quit()
                    sys.exit()
                    
                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_RETURN:
                        self.main_menu_sound.stop()
                      
                        running = False

            self.screen.fill('black')

           

            self.screen.blit(background_image, background_rect)

            font_title = pygame.font.Font(FONT, 60)
            title_text = font_title.render("UNDERTALE", True, (255, 255, 255))
            title_rect = title_text.get_rect(center=(WIDTH // 2, HEIGTH // 4 -130))
            self.screen.blit(title_text, title_rect)

            
            font = pygame.font.Font(FONT, 36)
            text = font.render("Press Enter to Start", True, (255, 255, 255))
            text_rect = text.get_rect(center=(WIDTH // 2, HEIGTH // 2))
            self.screen.blit(text, text_rect)

            pygame.display.update()
            self.clock.tick(FPS)

    


    def slideshow(self):

        """
        Displays a slideshow introducing the game's backstory with images and text.
        The method loads a series of images and presents them sequentially with accompanying text.
        Each slide remains visible for a set duration which is controlled with 'slide_duration' variable.

        The method exits the slideshow when all slides have been presented. Can also be closed by clicking on window's cross
        without causing any errors

        Returns:
        None

        """

        self.slideshow_sound.play(loops=-1) 


        intro_images = load_all_pics('intro/')
        lines = [
            "Long ago two races ruled the world: HUMANS and MONSTERS.",
            "One day, war broke between two races.",
            "After a long battle, the humans were victorious.",
            "Many years later: MT EBBOT 201X",
            "Legends say that those who climb the mountain...",
            "never return because of  m o n s t e r s",
            "",
            "",
            "",
        ]
        slide_duration = 3000  

        for i, intro_image in enumerate(intro_images):
            screen_rect = self.screen.get_rect()
            image_rect = intro_image.get_rect(center=screen_rect.center)

          
            self.screen.fill((0, 0, 0))

            self.screen.blit(intro_image, image_rect)

         
            line_index = i % len(lines)
            font = pygame.font.Font(FONT, 34) 
            text_surface = font.render(lines[line_index], True, (255, 255, 255))
            text_rect = text_surface.get_rect(center=(self.screen.get_width() // 2, self.screen.get_height() -120))
            self.screen.blit(text_surface, text_rect)

            pygame.display.update()

   
            start_time = pygame.time.get_ticks()

 
            while pygame.time.get_ticks() - start_time < slide_duration:
                for event in pygame.event.get():
                    if event.type == pygame.QUIT:
                        pygame.quit()
                        sys.exit()

        self.slideshow_sound.stop()

        self.screen.fill((0, 0, 0))
        pygame.display.update()
 
if __name__ == '__main__':
    game = Game()
    game.main_menu()
    game.slideshow() 
    game.run()