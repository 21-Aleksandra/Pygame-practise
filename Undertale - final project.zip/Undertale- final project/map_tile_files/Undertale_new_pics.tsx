<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="Undertale_new_pics" tilewidth="160" tileheight="184" tilecount="5" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="0">
  <image width="95" height="80" source="../levels/Objects/0.png"/>
 </tile>
 <tile id="1">
  <image width="28" height="22" source="../levels/Objects/1.png"/>
 </tile>
 <tile id="2">
  <image width="160" height="184" source="../levels/Objects/2.png"/>
 </tile>
 <tile id="3">
  <image width="60" height="60" source="../levels/Objects/3.png"/>
 </tile>
 <tile id="4">
  <image width="61" height="96" source="../levels/Objects/4.png"/>
 </tile>
</tileset>
