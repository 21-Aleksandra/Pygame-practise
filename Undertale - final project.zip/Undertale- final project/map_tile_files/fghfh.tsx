<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="fghfh" tilewidth="20" tileheight="20" tilecount="240" columns="24">
 <image source="../../Downloads/fghfh.png" width="499" height="200"/>
</tileset>
