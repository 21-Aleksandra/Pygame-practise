<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="random" tilewidth="16" tileheight="16" tilecount="1280" columns="16">
 <image source="../../Downloads/undertale_ruin_texture_sheets_rpg_maker_xp_by_typlosion14_dd93mig.png" width="256" height="1280"/>
</tileset>
