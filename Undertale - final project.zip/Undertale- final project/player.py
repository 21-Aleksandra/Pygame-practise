import pygame
from pygame.sprite import Sprite, Group
from setting import *
from support_functions import *
from creature import Creature

#inheretance class
class Player (Creature):

    """
    Represents the player character in the game and all its possible actions and charastrictics such as name, xp, the ability to hit etc.

    Attributes:
    - image : The player's current image surface or so-called idle state.
    - rect : The rectangular area occupied by the player.
    - sprite_type : The type of the sprite ('player').
    - doing_attack : Flag indicating whether the player is performing an attack.
    - attack_cooldown : Cooldown duration for player attacks.
    - attack_time : Timestamp of the last attack.
    - lvl_up (function): Function to handle level-up events.
    - create_att (function): Function to create player attacks.
    - status : Current motion status of the player.
    - destory_sword (function): Function to destroy the player's weapon.
    - weapon : The current weapon equipped by the player.
    - obstacle_sprites : Group containing obstacle sprites for collision detection.
    - hitbox : The rectangular area for collision detection.
    - stats : Dictionary containing player stats (health, XP, level, attack, speed).
    - health : Current health points of the player.
    - speed : Movement speed of the player.
    - XP : Experience points earned by the player.
    - lvl : Current level of the player.
    - name : Name of the player.
    - item_count : Count of items collected by the player.
    - vulnerable : Flag indicating if the player is currently vulnerable(can be hit).
    - hit_time : Timestamp of the last hit.
    - no_hit_duration: Duration of invincibility after being hit.
    - weapon_sound : the sound of waepon

    Methods:
    - __init__(self, pos, groups, obstacle_sprites, create_att, destory_sword, lvl_up) : Initializes a Player sprite.

    - load_player_grafics(self): Loads player motion graphics from the 'sprites_2' directory.

    - get_state(self): Updates the player's status based on key input and actions.

    - input(self):  Handles player input, updating the player's direction and status.

    - player_cooldown(self): Manages cooldowns for player  attacks.

    - animate(self):Animates the player based on the current status and motion graphics.

    - get_full_dmg(self): Calculates the total damage dealt by the player, including weapon damage.

    - lvl_up_player(self): Checks if the player has enough XP to level up and triggers the level-up event.

    - update(self):Updates the player's state, animation, movement, and handles cooldowns.

    """

    def __init__(self, pos, groups, obstacle_sprites,create_att,destory_sword,lvl_up):
        super().__init__(groups)
        self.image=pygame.image.load('sprites_2/down_idle/spr_front_1.png').convert_alpha()
        self.rect= self.image.get_rect(topleft=pos)
        self.sprite_type='player'
        self.doing_attack=False
        self.attack_cooldown=300
        self.attack_time=None
        self.load_player_grafics()
        self.lvl_up=lvl_up
        self.create_att=create_att
        self.status='down'
        self.destory_sword=destory_sword
        self.weapon=list(Weapon.keys())[0]
        self.obstacle_sprites=obstacle_sprites
        self.hitbox=self.rect.inflate(-2,-3)
        self.stats={'health':100, 'XP':150, 'level':1, 'attack':5,'speed':5}
        self.health=self.stats['health']
        self.speed=self.stats['speed']
        self.XP=0
        self.lvl=self.stats['level']
        self.name='Chara'
        self.item_count=0
        self.vulnerable = True
        self.hit_time = None
        self.no_hit_duration = 600
        self.weapon_sound=pygame.mixer.Sound('sound/Player_hit.mp3')
        self.weapon_sound.set_volume(0.3)
    
    def load_player_grafics(self):
        """
        This method loads player motion graphics(pictures for animation) from the 'sprites_2' directory
        where each subderectory coresponds to dictiotnary self.motions keys (e.g., 'up', 'down' etc.) and needed motion way .

        Returns:
        None

        """
        path='sprites_2/'
        self.motions= {'up':[], 'down':[], 'left':[], 'right':[],
                       'up_idle':[],'down_idle':[],'left_idle':[],'right_idle':[],
                       'up_attack':[],'down_attack':[],'left_attack':[],'right_attack':[],

        }

        for animation in self.motions.keys():
            full=path+animation+"/"
            self.motions[animation]=load_all_pics(full)





    def input(self):

        """
        The method handles player input for movement and attack.

        It updates the player's direction based on the arrow keys. Additionally, if the 'e' key is pressed and 
        the player is not already performing an attack (`self.doing_attack`),
        it initiates the attack by setting `self.doing_attack` to True, recording the attack time, and calling
        the `create_att()` methods

        Returns:
        None

  
        """
         
        keys=pygame.key.get_pressed()

        if keys[pygame.K_UP]:
            self.direction.y= -1
            self.status='up'
        elif keys[pygame.K_DOWN]:
            self.direction.y= 1
            self.status='down'
        else:
            self.direction.y= 0
        
        if keys[pygame.K_RIGHT]:
            self.direction.x= 1
            self.status='right'
        elif keys[pygame.K_LEFT]:
            self.direction.x= -1
            self.status='left'
        else:
            self.direction.x= 0

        if keys[pygame.K_e] and not self.doing_attack:
            self.doing_attack=True
            self.attack_time=pygame.time.get_ticks()
            self.create_att()
            self.weapon_sound.play()


    def get_state(self):
        
        """
        The method updates the player's state based on movement and attack actions.
        Checks the player's direction to determine whether they are idle, attacking, or moving in a specific direction.
        If the player is neither idle nor attacking, it removes '_attack' from the status.

        Returns:
        None
        """
        
        if self.direction.x==0 and self.direction.y==0:
            if not 'idle' in self.status and not 'attack'in self.status :
                self.status=self.status+"_idle"
        if self.doing_attack:
            self.direction.x=0
            self.direction.y=0
            if not 'attack' in self.status:
                if 'idle' in self.status:
                    self.status=self.status.replace('_idle','_attack')
                
                else:
                    self.status=self.status+"_attack"
        else:
             if 'attack' in self.status:
                 self.status=self.status.replace('_attack','')

    

    def animate(self):

        """
        The method animates the player's sprite based on the current motion status.
        Increases `self.anim_index` to progress through the animation frames.
        Resets `self.anim_index` to 0 when it reaches the end of the animation list.
    
        Returns:
        None

        """

        animations=self.motions[self.status]

        self.anim_index+=self.anim_speed
        if self.anim_index>=len(animations):
            self.anim_index=0

        self.image=animations[int(self.anim_index)]
        self.rect=self.image.get_rect(center=self.hitbox.center)
       
            
           

    def player_cooldown(self):
        """
        Manages the cooldown and invincibility duration for player attacks.

        Checks if if the attack cooldown duration has passed. If true, calls `self.destory_sword()` to remove the sword sprite and does not allow to attack.
        Checks if the player is currently in an invincible state and if the invincibility duration has passed. If true, makes valnurable.

        Returns:
        None
        """
        curr_timimg=pygame.time.get_ticks()
        if self.doing_attack:
            if curr_timimg- self.attack_time>=self.attack_cooldown:
                 self.destory_sword()
                 self.doing_attack=False
        if not self.vulnerable:
            if curr_timimg- self.hit_time>=self.no_hit_duration:
                self.vulnerable=True

  

    
    def get_full_dmg(self):
        att=int(self.stats['attack'])
        sword=int(Weapon['sword']['damage'])
      
        return att+sword
    
    
    def lvl_up_player(self):
        if self.XP==self.stats['XP']:
           self.lvl_up()



    def update(self):
        self.input()
        self.get_state()
        self.animate()
        self.move(self.speed)
        self.player_cooldown()
        self.lvl_up_player()
 
