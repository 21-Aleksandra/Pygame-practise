# General game settings that are easy to change and import to any file
WIDTH    = 1280 
HEIGTH   = 720
FPS      = 60
TILESIZE = 32


BAR_H=20
HEALTH_BAR_W=200
XP_BAR_W=120
I_BOX_SIZE=80
FONT='fonts/determinationmono.ttf'
STAND_FONT_SIZE= 20
UI_BG_COL='white'

H_COLOR='red'
XP_COLOR='green'



Weapon={'sword':{'cooldown':100,'damage':2, 'grafic':'weapon/sword_right.png'}}

Monster={
    'ghost':{'health':20, 'xp':50, 'damage':5,'speed':2,'hit_dist':5,'att_dist':70, 'notice_dist':300}
}

Boss={

    'health':100, 'xp':150, 'damage':15

}