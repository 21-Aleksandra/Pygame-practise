from csv import reader
from os import walk 
import pygame

#the file contains some support functions for loading files and pictures



def get_layout_from_csv(path):
    """
    Reads the CSV file at the specified path and saves it as a map.
    Each row in the CSV file is converted into a list, and all rows are appended
    to create a 2D list representing the map layout.

    Parameters:
    - path (str): Path to the CSV file.

    Returns:
    - list: 2D list representing the map layout.
    """
    map=[]
    with open(path) as level_col:
        layout= reader(level_col, delimiter=',')
        for row in layout:
            map.append(list(row))
    return map





def load_all_pics(path):

    """
    Iterates through all files in the specified directory, loads each image, and converts them to surfaces.

    Parameters:
    - path (str): Path to the directory containing images.

    Returns:
    - list: List of Pygame surfaces representing images.  

    """


    pic_list=[]
    for _,__,img_file in walk(path):
        for image in img_file:
            full_path= path + '/' + image
            image_surf = pygame.image.load(full_path).convert_alpha()
            pic_list.append(image_surf)

    return pic_list




        



