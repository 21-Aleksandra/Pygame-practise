import pygame
from setting import *

#ingeretance class
class Tile (pygame.sprite.Sprite):
    
    """
    Represents a tile in the game world.

    Attributes:
    - pos (tuple): Position of the tile on map.
    - groups (list): List of sprite groups the tile belongs to.
    - sprite_type (str): Type of the tile.
    - surface : Pygame surface representing the tile's image.
    - image : Pygame surface representing the tile's image.
    - rect : Pygame rectangle representing the tile's position and size.
    - hitbox (pygame.Rect): Pygame rectangle representing the tile's hitbox, basically shrinked rect.

    Methods:
    - __init__(self, pos, groups, sprite_type, surface=pygame.Surface((TILESIZE, TILESIZE))): Initializes a new Tile instance.

    """

    def __init__(self, pos, groups, sprite_type,surface=pygame.Surface((TILESIZE,TILESIZE))): # since map is desiged in Tiled, we need a proper tilesized tile
        super().__init__(groups)
        self.sprite_type=sprite_type
        self.image=surface
        self.rect= self.image.get_rect(topleft=pos)
        self.hitbox=self.rect.inflate(-15,-1)