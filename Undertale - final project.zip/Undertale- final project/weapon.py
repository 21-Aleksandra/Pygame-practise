import pygame


class Weapon(pygame.sprite.Sprite):

    """
    Represents a weapon and its sprite associated with a player as well as help to detect the position weapon facing

    Attributes:
    - image : The weapon's image surface.
    - sprite_type (str): The type of the sprite ('weapon').
    - rect : The rectangular area occupied by the weapon.

    Methods:
    - __init__(self, player, groups): Initializes a Weapon sprite.
        - player: Player object representing the associated player.
        - groups: Sprite groups to which weapon sprite belongs.

     """





    def __init__(self, player, groups):
        super().__init__(groups)               #making sure that the sprite is properly initialized as part of the sprite group
        way_facing=player.status.split('_')[0] # first part of player status before _ is direction
        path=f'weapon/{way_facing}.png'
        self.image= pygame.image.load(path).convert_alpha()
        self.sprite_type='weapon'

        
       

        
        # vecotr2 is for positionong weapon around player
        if way_facing=='right':
            self.rect=self.image.get_rect(midleft=player.rect.midright+pygame.math.Vector2(-15,5)) 
        elif way_facing=='left':
            self.rect=self.image.get_rect(midleft=player.rect.midleft+pygame.math.Vector2(-15,5))
        elif way_facing=='down':
            self.rect=self.image.get_rect(midtop=player.rect.midbottom+pygame.math.Vector2(0,-15))

        else:
             self.rect=self.image.get_rect(midbottom=player.rect.midtop+pygame.math.Vector2(0,5))

     
        

        
        